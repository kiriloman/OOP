package pec;

public class Event {
    public double time;

    public Event(double time) {
        this.time = time;
    }

    public void execute() {

    }

    public double getTime(){
        return time;
    }
}
