package pec;

import population.Population;

public class Death extends EventInd {

    public Death(double time) {
        super(time);
    }

    @Override
    public void execute() {
        //System.out.println("Died host number:" + this.getHost().getId() + " time: " + this.getTime());
        Population.removeIndividual(this.getHost());
    }
}
