package grid;

public interface Grid {
}
